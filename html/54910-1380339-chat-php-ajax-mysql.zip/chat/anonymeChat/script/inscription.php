<?php
require ('functions.php');
bdd_connect();
inscription();
?>
