<!DOCTYPE html>
<html>
<head>
<script src="a.js"></script>
<meta charset="UTF-8" language="FR" />
</head>
<body>
<center><div id="a"><h1 id="ab">Chargement ...</h1><br /></div></center><center><h2><div id="bip" class="display"></div></h2></center><center><button onclick="start()" value="ok" id="button" style="visibility:hidden" ></button></center>
</body>
</html>
