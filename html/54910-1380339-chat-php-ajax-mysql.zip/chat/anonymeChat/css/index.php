<?php
header('Location: ./../chat.php');
?>